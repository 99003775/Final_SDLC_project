#ifndef __OPERATION_H__
#define __OPERATION_H__

#include<stdio.h>
#include<stdlib.h>
#include<math.h>

int add(int,int);
int subtract(int,int);
int multiply(int,int);
int divide(int,int);

#endif
