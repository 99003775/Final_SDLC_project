#ifndef __TRIGONOMETRY_H__
#define __TRIGONOMETRY_H__
#include<stdio.h>
#include<math.h>
void trig();
float sin_angle(float degree);
float cos_angle(float degree);
float tan_angle(float degree);
float cosec_angle(float degree);
float sec_angle(float degree);
float cot_angle(float degree);
#endif
