#ifndef __CONVERSION_H__
#define __CONVERSION_H__


#include<stdio.h>
#include<math.h>
void conversion();
float Celsius(float);
float Kelvin(float);
float Kelvin_F(float);
float F_K(float);
float F_C(float);
float C_F(float);

float I_D(float);
float D_I(float);
float I_P(float);
float P_I(float);
float D_P(float);
float P_D(float);


#endif  /* #define __CONVERSION_H___ */
